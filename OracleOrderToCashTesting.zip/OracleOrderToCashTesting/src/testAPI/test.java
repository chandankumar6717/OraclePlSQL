package testAPI;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.openqa.selenium.JavascriptExecutor;

import oracle.openBrowser.OpenFireFox;
import oracle.openBrowser.OpenIE;
import org.apache.commons.*;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;
import static oracle.logger.LogFile.start_logging;

public class test {

	private static final Logger logr = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public static void main(String[] args) {

		String path = System.getProperty("user.dir");
		// result: C:\Users\Chandan\eclipse-workspace\OracleOrderToCashTesting

		start_logging();
		logr.info("logging has been started with from test class");

		//OpenIE openIE = new OpenIE();
		//WebDriver driverIE = openIE.OpenIE64();
		OpenFireFox openFireFox = new OpenFireFox();
		WebDriver driverFox = openFireFox.OpenMozilla64();

		driverFox.manage().window().maximize();
		driverFox.get("https://www.google.com/");

		// image operations
		// ImagePath.setBundlePath(path + "\\resources\\images\\TestPics");
		// String picPath = ImagePath.getBundlePath() + "\\google_test.png";
		 String picPath = path + "\\resources\\images\\TestPics\\pic2.png";
		// String picPath = path + "\\oracle\\orderEntry\\image\\google_test1.png";
		
		Screen screen = new Screen();

		try {

			
			screen.type("hello world!!!!");
			screen.type(Key.TAB);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Pattern image = new Pattern(picPath);
			screen.click(image);
			//screen.type(Key.ENTER);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			checkPageIsReady( driverFox);
			
	    TakesScreenshot sh = (TakesScreenshot)driverFox;
		File source = sh.getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(source, new File("./ScreenShots/OrderHeaderEntry.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			

		} catch (FindFailed e) {
			logr.severe(e.toString());
			e.printStackTrace();
		}
		/*try {
			driverIE.close();	//not working why??		
		}catch(Exception e){
			e.printStackTrace();
		}*/
		
	}
	
	 public static void checkPageIsReady(WebDriver driver) {
		  
		  JavascriptExecutor js = (JavascriptExecutor)driver;
		  
		  
		  //Initially bellow given if condition will check ready state of page.
		  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   System.out.println("Page Is loaded.");
		   return; 
		  } 
		  
		  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
		  //You can replace your value with 25 If you wants to Increase or decrease wait time.
		  for (int i=0; i<25; i++){ 
		   try {
		    Thread.sleep(1000);
		    }catch (InterruptedException e) {} 
		   //To check page ready state.
		   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		    break; 
		   }   
		  }
		 }

}
