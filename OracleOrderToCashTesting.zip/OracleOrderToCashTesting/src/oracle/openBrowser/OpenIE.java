package oracle.openBrowser;

//import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class OpenIE {
	//private static final Logger logr = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	public WebDriver OpenIE64() {
		//logr.info("another class");
		final String IEdriverPath;
		String path = System.getProperty("user.dir");
		System.out.println(path); 
		
		IEdriverPath = path+"\\resources\\webDrivers\\IE64\\IEDriverServer.exe";
		
		System.out.println(IEdriverPath); 

		System.setProperty("webdriver.ie.driver", IEdriverPath);

		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();

		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		//capabilities.setCapability("initialBrowserUrl", "https://my-page:9443");
		//capabilities.setCapability("ignoreZoomSetting", true);
		//capabilities.setCapability("EnableNativeEvents", false);

		@SuppressWarnings("deprecation")
		WebDriver driver = new InternetExplorerDriver(capabilities);

		// Navigate to URL
		// driver.get("https://mail.google.com/");
		return driver;

	}

}
