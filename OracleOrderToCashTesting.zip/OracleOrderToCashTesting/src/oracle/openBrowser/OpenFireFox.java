package oracle.openBrowser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenFireFox {

	// private static final Logger logr = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	public WebDriver OpenMozilla64() {
		// logr.info("another class");
		final String MozilladriverPath;
		String path = System.getProperty("user.dir");
		System.out.println(path);

		MozilladriverPath = path + "\\resources\\webDrivers\\Mozila64\\geckodriver.exe";

		System.out.println(MozilladriverPath);

		System.setProperty("webdriver.gecko.driver", MozilladriverPath);

		WebDriver driver = new FirefoxDriver();

		return driver;

	}

}
