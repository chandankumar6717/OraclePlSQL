package oracle.orderEntry.prcoess;

public class EnterOrderHdrDtls {

}
