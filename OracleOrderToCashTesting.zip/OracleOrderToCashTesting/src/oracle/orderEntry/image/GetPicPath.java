package oracle.orderEntry.image;

public class GetPicPath {

}
